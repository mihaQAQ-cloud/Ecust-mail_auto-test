import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split

# ==========================================
# 1. 辅助函数：激活函数及其导数、独热编码
# ==========================================

def relu(z):
    """ReLU 激活函数"""
    return np.maximum(0, z)

def relu_deriv(z):
    """ReLU 激活函数的导数：大于0为1，小于等于0为0"""
    return z > 0

def softmax(z):
    """Softmax 激活函数（加入减去最大值的操作防止指数爆炸）"""
    exp_z = np.exp(z - np.max(z, axis=1, keepdims=True))
    return exp_z / np.sum(exp_z, axis=1, keepdims=True)

def one_hot(y, num_classes=10):
    """将标签转换为 One-Hot 编码"""
    m = y.shape[0]
    one_hot_y = np.zeros((m, num_classes))
    one_hot_y[np.arange(m), y] = 1
    return one_hot_y

# ==========================================
# 2. 神经网络核心类
# ==========================================

class SimpleNeuralNetwork:
    def __init__(self, input_size=784, hidden_size=64, output_size=10, learning_rate=0.1):
        # 使用 He 初始化方法初始化权重，偏置初始化为 0
        self.W1 = np.random.randn(input_size, hidden_size) * np.sqrt(2. / input_size)
        self.b1 = np.zeros((1, hidden_size))
        
        self.W2 = np.random.randn(hidden_size, output_size) * np.sqrt(2. / hidden_size)
        self.b2 = np.zeros((1, output_size))
        
        self.lr = learning_rate

    def forward(self, X):
        """前向传播"""
        self.Z1 = np.dot(X, self.W1) + self.b1
        self.A1 = relu(self.Z1)
        
        self.Z2 = np.dot(self.A1, self.W2) + self.b2
        self.A2 = softmax(self.Z2)
        
        return self.A2

    def backward(self, X, Y_true):
        """反向传播与参数更新"""
        m = X.shape[0]

        # 1. 计算输出层梯度
        dZ2 = self.A2 - Y_true
        dW2 = np.dot(self.A1.T, dZ2) / m
        db2 = np.sum(dZ2, axis=0, keepdims=True) / m

        # 2. 计算隐藏层梯度
        dA1 = np.dot(dZ2, self.W2.T)
        dZ1 = dA1 * relu_deriv(self.Z1)
        dW1 = np.dot(X.T, dZ1) / m
        db1 = np.sum(dZ1, axis=0, keepdims=True) / m

        # 3. 梯度下降更新参数
        self.W1 -= self.lr * dW1
        self.b1 -= self.lr * db1
        self.W2 -= self.lr * dW2
        self.b2 -= self.lr * db2

    def compute_loss(self, Y_pred, Y_true):
        """计算交叉熵损失"""
        m = Y_true.shape[0]
        # 加上微小值 epsilon 防止 np.log(0) 报错
        epsilon = 1e-15
        loss = -np.sum(Y_true * np.log(Y_pred + epsilon)) / m
        return loss

    def predict(self, X):
        """预测函数，返回概率最大的类别索引"""
        A2 = self.forward(X)
        return np.argmax(A2, axis=1)

# ==========================================
# 3. 数据加载与训练流程
# ==========================================

if __name__ == "__main__":
    print("正在下载/加载 MNIST 数据集... (可能需要几十秒)")
    # 从 openml 获取 MNIST 数据，返回的是 Pandas DataFrame，我们转换为 numpy array
    mnist = fetch_openml('mnist_784', version=1, as_frame=False, parser='auto')
    
    X, y = mnist["data"], mnist["target"].astype(int)
    
    # 归一化：将像素值从 0-255 缩放到 0-1 之间，这对于神经网络的收敛至关重要
    X = X / 255.0
    
    # 划分训练集和测试集 (80% 训练，20% 测试)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 将训练标签转换为 One-Hot 编码
    y_train_onehot = one_hot(y_train)
    y_test_onehot = one_hot(y_test)

    # 初始化网络 (学习率设为 0.5)
    nn = SimpleNeuralNetwork(input_size=784, hidden_size=64, output_size=10, learning_rate=0.5)

    epochs = 500
    print("\n开始训练...")
    
    # 这里我们使用全批量梯度下降 (Full-batch Gradient Descent) 
    # 如果想更快，可以自己实现小批量 (Mini-batch)
    for epoch in range(epochs):
        # 1. 前向传播
        predictions = nn.forward(X_train)
        
        # 2. 计算损失
        loss = nn.compute_loss(predictions, y_train_onehot)
        
        # 3. 反向传播
        nn.backward(X_train, y_train_onehot)
        
        # 4. 打印进度
        if (epoch + 1) % 50 == 0:
            train_acc = np.mean(np.argmax(predictions, axis=1) == y_train)
            print(f"Epoch {epoch+1}/{epochs} - Loss: {loss:.4f} - Train Acc: {train_acc:.4f}")

    # ==========================================
    # 4. 最终测试集评估
    # ==========================================
    test_preds = nn.predict(X_test)
    test_acc = np.mean(test_preds == y_test)
    print(f"\n训练完成! 测试集最终准确率: {test_acc:.4f}")